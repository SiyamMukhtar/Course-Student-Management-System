<?php
require 'header.php';
require 'db_config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: manage_courses.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM course WHERE course_id=?");
$stmt->execute([$id]);
$course = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['course_code']);
    $title = trim($_POST['title']);
    $credits = trim($_POST['credits']);

    $update = $pdo->prepare("UPDATE course SET course_code=?, title=?, credits=? WHERE course_id=?");
    $update->execute([$code, $title, $credits, $id]);

    header("Location: manage_courses.php");
    exit;
}
?>

<div class="card p-4">
    <h3 class="fw-bold mb-3"><i class="fa-solid fa-book-pen"></i> Edit Course</h3>
    <form method="POST">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Course Code</label>
                <input type="text" name="course_code" class="form-control" value="<?= htmlspecialchars($course['code']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Course Title</label>
                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($course['title']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Credits</label>
                <input type="number" name="credits" class="form-control" value="<?= $course['credits'] ?>" required>
            </div>
        </div>
        <div class="mt-4">
            <button type="submit" class="btn btn-success"><i class="fa-solid fa-save"></i> Update</button>
            <a href="manage_courses.php" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Cancel</a>
        </div>
    </form>
</div>

<?php require 'footer.php'; ?>

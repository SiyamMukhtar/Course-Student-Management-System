<?php
require 'header.php';
require 'db_config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: manage_students.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM student WHERE student_id=?");
$stmt->execute([$id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
$courses = $pdo->query("SELECT * FROM course ORDER BY title")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $dob = $_POST['dob'];
    $course_id = $_POST['course_id'] ?: null;

    $update = $pdo->prepare("UPDATE student SET fname=?, lname=?, email=?, dob=?, course_id=? WHERE student_id=?");
    $update->execute([$fname, $lname, $email, $dob, $course_id, $id]);

    header("Location: manage_students.php");
    exit;
}
?>

<div class="card p-4">
    <h3 class="fw-bold mb-3"><i class="fa-solid fa-user-pen"></i> Edit Student</h3>
    <form method="POST">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">First Name</label>
                <input type="text" name="fname" class="form-control" value="<?= htmlspecialchars($student['fname']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Last Name</label>
                <input type="text" name="lname" class="form-control" value="<?= htmlspecialchars($student['lname']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($student['email']) ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($student['dob']) ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Course</label>
                <select name="course_id" class="form-select">
                    <option value="">-- None --</option>
                    <?php foreach($courses as $c): ?>
                        <option value="<?= $c['course_id'] ?>" <?= ($c['course_id']==$student['course_id'])?'selected':''; ?>>
                            <?= htmlspecialchars($c['title']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="mt-4">
            <button type="submit" class="btn btn-success"><i class="fa-solid fa-save"></i> Update</button>
            <a href="manage_students.php" class="btn btn-secondary"><i class="fa-solid fa-arrow-left"></i> Cancel</a>
        </div>
    </form>
</div>

<?php require 'footer.php'; ?>

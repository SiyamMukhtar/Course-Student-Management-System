<?php
require 'header.php';
require 'db_config.php';

// Fetch courses
$stmt = $pdo->query("SELECT course_id, code, title, credits FROM course ORDER BY course_id DESC");
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold"><i class="fa-solid fa-book-open text-success"></i> Manage Courses</h2>
    <a href="add_course.php" class="btn btn-success">
        <i class="fa-solid fa-plus"></i> Add Course
    </a>
</div>

<div class="card p-4 shadow-sm">
    <?php if (count($courses) === 0): ?>
        <div class="alert alert-info text-center mb-0">
            No courses found. <a href="add_course.php" class="alert-link">Add a new course</a>.
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Course Code</th>
                        <th>Title</th>
                        <th>Credits</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c['course_id']) ?></td>
                            <td><?= htmlspecialchars($c['code']) ?></td>
                            <td><?= htmlspecialchars($c['title']) ?></td>
                            <td><?= htmlspecialchars($c['credits']) ?></td>
                            <td>
                                <a href="edit_course.php?id=<?= $c['course_id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fa-solid fa-pen-to-square"></i> Edit
                                </a>
                                <a href="delete_course.php?id=<?= $c['course_id'] ?>"
                                   onclick="return confirm('Are you sure you want to delete this course?')"
                                   class="btn btn-sm btn-danger">
                                    <i class="fa-solid fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require 'footer.php'; ?>

<?php
require 'header.php';
require 'db_config.php';

// Fetch students and their courses
$stmt = $pdo->query("SELECT s.student_id, s.fname, s.lname, s.email, s.dob, c.title AS course 
                     FROM student s 
                     LEFT JOIN course c ON s.course_id = c.course_id 
                     ORDER BY s.student_id DESC");
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold"><i class="fa-solid fa-users text-primary"></i> Manage Students</h2>
    <a href="add_student.php" class="btn btn-primary">
        <i class="fa-solid fa-user-plus"></i> Add Student
    </a>
</div>

<div class="card p-4 shadow-sm">
    <?php if (count($students) === 0): ?>
        <div class="alert alert-info text-center mb-0">
            No students found. <a href="add_student.php" class="alert-link">Add a new student</a>.
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>DOB</th>
                        <th>Course</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $s): ?>
                        <tr>
                            <td><?= htmlspecialchars($s['student_id']) ?></td>
                            <td><?= htmlspecialchars($s['fname'] . ' ' . $s['lname']) ?></td>
                            <td><?= htmlspecialchars($s['email']) ?></td>
                            <td><?= $s['dob'] ? htmlspecialchars($s['dob']) : '-' ?></td>
                            <td><?= $s['course'] ? htmlspecialchars($s['course']) : '—' ?></td>
                            <td>
                                <a href="edit_student.php?id=<?= $s['student_id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fa-solid fa-pen-to-square"></i> Edit
                                </a>
                                <a href="delete_student.php?id=<?= $s['student_id'] ?>"
                                   onclick="return confirm('Are you sure you want to delete this student?')"
                                   class="btn btn-sm btn-danger">
                                    <i class="fa-solid fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require 'footer.php'; ?>

<?php
// header.php
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>University Manager</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8f9fa; }
        .navbar { box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .container-custom { max-width: 1100px; margin: 0 auto; padding: 20px; }
        .card { border-radius: 12px; box-shadow: 0 2px 20px rgba(0,0,0,0.05); }
        .btn { border-radius: 6px; }
        footer { text-align:center; margin-top:40px; font-size:14px; color:#777; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-primary navbar-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="home.php"><i class="fa-solid fa-graduation-cap"></i> University Manager</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="home.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="manage_students.php">Students</a></li>
        <li class="nav-item"><a class="nav-link" href="manage_courses.php">Courses</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-custom">

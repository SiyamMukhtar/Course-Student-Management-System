<?php
// add_student.php
require 'header.php';
require 'db_config.php';

$errors = [];
// fetch courses for dropdown
$courses = $pdo->query("SELECT course_id, title FROM course ORDER BY title ASC")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname'] ?? '');
    $lname = trim($_POST['lname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $dob = $_POST['dob'] ?: null;
    $course_id = ($_POST['course_id'] !== '') ? (int)$_POST['course_id'] : null;

    if ($fname === '' || $lname === '' || $email === '') {
        $errors[] = "First name, last name and email are required.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO student (fname, lname, email, dob, course_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$fname, $lname, $email, $dob, $course_id]);
            header('Location: manage_students.php');
            exit;
        } catch (PDOException $ex) {
            // handle duplicate email gracefully
            if (isset($ex->errorInfo[1]) && $ex->errorInfo[1] == 1062) {
                $errors[] = "Email already exists. Use a different email.";
            } else {
                $errors[] = "Insert failed: " . htmlspecialchars($ex->getMessage());
            }
        }
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold"><i class="fa-solid fa-user-plus text-primary"></i> Add Student</h2>
    <a class="btn btn-secondary" href="manage_students.php"><i class="fa-solid fa-arrow-left"></i> Back to Students</a>
</div>

<div class="card p-4">
    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?>
        </div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">First Name</label>
                <input name="fname" class="form-control" value="<?= isset($fname) ? htmlspecialchars($fname) : '' ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Last Name</label>
                <input name="lname" class="form-control" value="<?= isset($lname) ? htmlspecialchars($lname) : '' ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Email</label>
                <input name="email" type="email" class="form-control" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Date of Birth</label>
                <input name="dob" type="date" class="form-control" value="<?= isset($dob) && $dob ? htmlspecialchars($dob) : '' ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">Course (optional)</label>
                <select name="course_id" class="form-select">
                    <option value="">-- none --</option>
                    <?php foreach($courses as $c): ?>
                        <option value="<?= $c['course_id'] ?>" <?= (isset($course_id) && $course_id == $c['course_id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['title']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Add Student</button>
            <a class="btn btn-outline-secondary" href="manage_students.php">Cancel</a>
        </div>
    </form>
</div>

<?php require 'footer.php'; ?>

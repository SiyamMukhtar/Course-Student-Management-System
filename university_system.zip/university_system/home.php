<?php require 'header.php'; require 'db_config.php'; ?>

<div class="text-center mb-4">
    <h1 class="fw-bold">University Dashboard</h1>
    <p class="text-muted">Manage courses and students with ease</p>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card p-4 text-center">
            <h3><i class="fa-solid fa-users text-primary"></i></h3>
            <h4><?php echo $pdo->query("SELECT COUNT(*) FROM student")->fetchColumn(); ?></h4>
            <p class="text-muted">Total Students</p>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card p-4 text-center">
            <h3><i class="fa-solid fa-book text-success"></i></h3>
            <h4><?php echo $pdo->query("SELECT COUNT(*) FROM course")->fetchColumn(); ?></h4>
            <p class="text-muted">Total Courses</p>
        </div>
    </div>
</div>

<div class="d-flex justify-content-center mt-4 gap-3">
    <a href="manage_students.php" class="btn btn-primary btn-lg"><i class="fa-solid fa-user-graduate"></i> Manage Students</a>
    <a href="manage_courses.php" class="btn btn-success btn-lg"><i class="fa-solid fa-book"></i> Manage Courses</a>
</div>

<?php require 'footer.php'; ?>

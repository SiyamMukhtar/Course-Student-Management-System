<?php
// add_course.php
require 'header.php';
require 'db_config.php';

$errors = [];
// detect whether course code column is 'course_code' or 'code'
$colCheck = $pdo->query("SHOW COLUMNS FROM course LIKE 'course_code'")->fetch();
$codeColumn = $colCheck ? 'course_code' : 'code';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_code = trim($_POST['course_code'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $credits = (int)($_POST['credits'] ?? 3);

    if ($course_code === '' || $title === '') {
        $errors[] = "Course code and title are required.";
    } else {
        try {
            if ($codeColumn === 'course_code') {
                $stmt = $pdo->prepare("INSERT INTO course (course_code, title, credits) VALUES (?, ?, ?)");
            } else {
                $stmt = $pdo->prepare("INSERT INTO course (code, title, credits) VALUES (?, ?, ?)");
            }
            $stmt->execute([$course_code, $title, $credits]);
            header('Location: manage_courses.php');
            exit;
        } catch (PDOException $ex) {
            $errors[] = "Insert failed: " . htmlspecialchars($ex->getMessage());
        }
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold"><i class="fa-solid fa-square-plus text-success"></i> Add Course</h2>
    <a class="btn btn-secondary" href="manage_courses.php"><i class="fa-solid fa-arrow-left"></i> Back to Courses</a>
</div>

<div class="card p-4">
    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?php echo implode('<br>', array_map('htmlspecialchars', $errors)); ?>
        </div>
    <?php endif; ?>

    <form method="post" novalidate>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Course Code</label>
                <input name="course_code" class="form-control" value="<?= isset($course_code) ? htmlspecialchars($course_code) : '' ?>" placeholder="e.g., CS101" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Course Title</label>
                <input name="title" class="form-control" value="<?= isset($title) ? htmlspecialchars($title) : '' ?>" placeholder="e.g., Intro to Programming" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Credits</label>
                <input name="credits" type="number" min="1" class="form-control" value="<?= isset($credits) ? (int)$credits : 3 ?>">
            </div>
        </div>

        <div class="mt-4">
            <button class="btn btn-success" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Course</button>
            <a class="btn btn-outline-secondary" href="manage_courses.php">Cancel</a>
        </div>
    </form>
</div>

<?php require 'footer.php'; ?>
